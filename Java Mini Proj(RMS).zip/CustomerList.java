import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CustomerList {
    public void openCustomer(){
        JFrame root=new JFrame();
        root.setTitle("Customer List");
        root.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        root.setSize(800, 600);
        root.setLocationRelativeTo(null);

        // Create a panel for the title
        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel("Customer List");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titlePanel.setBackground(new Color(14, 236, 228)); // Set your desired background color
        titlePanel.setForeground(Color.WHITE); // Set text color
        titlePanel.add(titleLabel);

        // Create a table model to hold the data
        DefaultTableModel model = new DefaultTableModel();
        JTable customerTable = new JTable(model);
        customerTable.setGridColor(Color.BLACK); // Set grid color
        customerTable.setBackground(new Color(240, 240, 240)); // Set table background color

        // Add columns to the table model
        model.addColumn("Customer ID");
        model.addColumn("Name");
        model.addColumn("Phone");
        model.addColumn("Bill No");
        model.addColumn("Total Bill");

        try {
            // Connect to the database
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/rms", "root", "#Lakshanika2004");

            // Execute a SQL query to retrieve data from the customer table
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM customer";
            ResultSet resultSet = statement.executeQuery(query);

            // Populate the table model with data from the query result
            while (resultSet.next()) {
                model.addRow(new Object[]{
                    resultSet.getString("cust_id"),
                    resultSet.getString("cust_name"),
                    resultSet.getString("cust_phone"),
                    resultSet.getString("bill_no"),
                    resultSet.getString("tot_bill")
                });
            }

            // Close the database connection
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(customerTable);

        // Set the appearance of the frame
        root.getContentPane().setBackground(new Color(255, 255, 255)); // Set the background color of the frame

        // Add the title panel to the frame at the top
        root.add(titlePanel, BorderLayout.NORTH);

        // Add the table to the frame
        root.add(scrollPane);

        root.setVisible(true);
    }
}

