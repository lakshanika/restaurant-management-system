import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Restaurant_Review {
    private JFrame frame;
    private JComboBox<Integer> ratingComboBox;
    private JTextArea reviewTextArea;
    private JButton submitButton;
    private JTextArea displayArea;
    private ArrayList<Review> reviews;

    private JTextField customerNameField;
    private JTextField phoneNumberField;

    
    public Restaurant_Review() {
        reviews = new ArrayList<>();
        frame = new JFrame("Restaurant Review System");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(435, 635);
        frame.setLayout(null); // Use null layout

        createComponents();

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void createComponents() {
        // Create a panel for the title
        JPanel titlePanel = new JPanel();
        titlePanel.setBounds(10, 10, 400, 30);
        titlePanel.setBackground(new Color(14, 236, 228)); // Set the background color
        titlePanel.setForeground(Color.WHITE); // Set text color

        JLabel titleLabel = new JLabel("REVIEWS AND RATINGS");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titlePanel.add(titleLabel);

        frame.add(titlePanel);

        // Create input panel
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(null);

        JLabel ratingLabel = new JLabel("GIVE YOUR RATINGS HERE (1-5):");
        ratingLabel.setBounds(10, 50, 200, 30);

        ratingComboBox = new JComboBox<>(new Integer[]{1, 2, 3, 4, 5});
        ratingComboBox.setBounds(220, 50, 80, 30);

        JLabel starLabel = new JLabel();
        ImageIcon starIcon = new ImageIcon("star.png");
        starLabel.setIcon(starIcon);
        starLabel.setBounds(310, 50, starIcon.getIconWidth(), starIcon.getIconHeight());

        JLabel reviewLabel = new JLabel("GIVE YOUR REVIEWS HERE:");
        reviewLabel.setBounds(10, 90, 200, 30);

        reviewTextArea = new JTextArea(5, 20);
        reviewTextArea.setWrapStyleWord(true);
        reviewTextArea.setLineWrap(true);
        reviewTextArea.setBounds(10, 130, 380, 100);

        // Add the new JLabel and JTextField for the customer's name
        JLabel customerNameLabel = new JLabel("Customer Name:");
        customerNameLabel.setBounds(10, 240, 200, 30);
        customerNameField = new JTextField(); // Use the instance variable
        customerNameField.setBounds(150, 240, 200, 30);

        // Add the new JLabel and JTextField for the customer's phone number
        JLabel phoneNumberLabel = new JLabel("Phone Number:");
        phoneNumberLabel.setBounds(10, 280, 200, 30);
        phoneNumberField = new JTextField(); // Use the instance variable
        phoneNumberField.setBounds(150, 280, 200, 30);

        submitButton = new JButton("SUBMIT REVIEW");
        submitButton.setBounds(160, 320, 130, 30);

        // Set colors for components
        titlePanel.setForeground(Color.WHITE); // Set text color for the title
        inputPanel.setBackground(Color.BLACK);
        ratingLabel.setForeground(Color.CYAN);
        starLabel.setForeground(Color.ORANGE);
        reviewLabel.setForeground(Color.CYAN);
        customerNameLabel.setForeground(Color.CYAN);
        customerNameField.setForeground(Color.black);
        phoneNumberLabel.setForeground(Color.CYAN);
        phoneNumberField.setForeground(Color.black);
        reviewTextArea.setBackground(Color.WHITE);
        submitButton.setBackground(Color.GRAY);
        submitButton.setForeground(Color.BLACK);


        // Add components to the input panel
        inputPanel.add(ratingLabel);
        inputPanel.add(ratingComboBox);
        inputPanel.add(starLabel);
        inputPanel.add(reviewLabel);
        inputPanel.add(reviewTextArea);

        // Add the new components for customer name and phone number
        inputPanel.add(customerNameLabel);
        inputPanel.add(customerNameField);
        inputPanel.add(phoneNumberLabel);
        inputPanel.add(phoneNumberField);

        inputPanel.add(submitButton);

        // Set the position and size of the input panel
        inputPanel.setBounds(10, 60, 400, 360);

        frame.add(inputPanel);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String customerName = customerNameField.getText();
                String phoneNumber = phoneNumberField.getText();
                int rating = (int) ratingComboBox.getSelectedItem();
                String reviewText = reviewTextArea.getText();
                Date date = new Date();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String formattedDate = dateFormat.format(date);

                Review review = new Review(customerName, phoneNumber, rating, reviewText, formattedDate);
                reviews.add(review);

                // Save the review to the database
                saveReviewToDatabase(review);

                displayReviews();
                clearInputFields();
            }
        });
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setBackground(Color.WHITE);
        displayArea.setLineWrap(true);
        displayArea.setWrapStyleWord(true);
        displayArea.setBounds(10, 390, 400, 150);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(10, 390, 400, 200);
        frame.add(scrollPane);

        // Load and display existing reviews from the database
        ArrayList<Review> existingReviews = retrieveReviewsFromDatabase();
        for (Review review : existingReviews) {
            reviews.add(review);
        }
    }

    private void saveReviewToDatabase(Review review) {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/rms", "root", "#Lakshanika2004");
            String sql = "INSERT INTO reviews (customer_name, phone_number, date, rating, review) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, review.getCustomerName());
            statement.setString(2, review.getPhoneNumber());
            statement.setString(3, review.getDate());
            statement.setInt(4, review.getRating());
            statement.setString(5, review.getReviewText());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private ArrayList<Review> retrieveReviewsFromDatabase() {
        ArrayList<Review> reviews = new ArrayList<>();
        Connection conn = null;
        try {
        	 conn = DriverManager.getConnection("jdbc:mysql://localhost/rms", "root", "#Lakshanika2004");
            String sql = "SELECT customer_name, phone_number, date, rating, review FROM reviews";
            PreparedStatement statement = conn.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String customerName = resultSet.getString("customer_name");
                String phoneNumber = resultSet.getString("phone_number");
                String date = resultSet.getString("date");
                int rating = resultSet.getInt("rating");
                String reviewText = resultSet.getString("review");
                Review review = new Review(customerName, phoneNumber, rating, reviewText, date);
                reviews.add(review);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return reviews;
    }


    private void displayReviews() {
        displayArea.setText("Restaurant Reviews:\n\n");
        for (Review review : reviews) {
        	displayArea.append("Customer Name: " + review.getCustomerName() + "\n");
            displayArea.append("Phone Number: " + review.getPhoneNumber() + "\n");
            displayArea.append("Rating: " + review.getRating() + " ");
            for (int i = 0; i < review.getRating(); i++) {
                displayArea.append("★");
            }
            displayArea.append("\n");
            displayArea.append("Review Date: " + review.getDate() + "\n");
            displayArea.append("Review: " + review.getReviewText() + "\n");
            displayArea.append("-------------------------------\n");
        }
    }





    private void clearInputFields() {
        ratingComboBox.setSelectedItem(1);
        reviewTextArea.setText("");
        // Clear customer name and phone number fields
        customerNameField.setText("");
        phoneNumberField.setText("");
    }


    public static void main(String[] args) {
        
            new Restaurant_Review();
        ;
    }
}

class Review {
    private String customerName;
    private String phoneNumber;
    private int rating;
    private String reviewText;
    private String date;

    public Review(String customerName, String phoneNumber, int rating, String reviewText, String date) {
        this.customerName = customerName;
        this.phoneNumber = phoneNumber;
        this.rating = rating;
        this.reviewText = reviewText;
        this.date = date;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public int getRating() {
        return rating;
    }

    public String getReviewText() {
        return reviewText;
    }

    public String getDate() {
        return date;
    }
}