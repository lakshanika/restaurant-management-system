
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddMenuWindow {
    private JTextField itemIDField, itemNameField, priceField;
    private JComboBox<String> categoryCombo, itemTypeCombo;

    public AddMenuWindow() {
        JFrame menuFrame = new JFrame("Add Menu");
        menuFrame.setBounds(200, 200, 542, 390);
        menuFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        menuFrame.setLayout(new BorderLayout());
        menuFrame.setLocationRelativeTo(null);

        JPanel newMenuPanel = new JPanel();
        newMenuPanel.setBackground(Color.decode("#0DECE4"));
        newMenuPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Add Menu"));
        newMenuPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        JLabel itemIDLabel = new JLabel("Item ID:");
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(10, 10, 10, 10);
        newMenuPanel.add(itemIDLabel, c);

        itemIDField = new JTextField(10);
        c.gridx = 1;
        newMenuPanel.add(itemIDField, c);

        JLabel itemNameLabel = new JLabel("Item Name:");
        c.gridx = 0;
        c.gridy = 1;
        newMenuPanel.add(itemNameLabel, c);

        itemNameField = new JTextField(10);
        c.gridx = 1;
        newMenuPanel.add(itemNameField, c);

        JLabel categoryLabel = new JLabel("Category:");
        c.gridx = 0;
        c.gridy = 2;
        newMenuPanel.add(categoryLabel, c);

        String[] categories = {"starter", "Beverages", "Main course"};
        categoryCombo = new JComboBox<>(categories);
        c.gridx = 1;
        newMenuPanel.add(categoryCombo, c);

        JLabel typeLabel = new JLabel("Type:");
        c.gridx = 0;
        c.gridy = 3;
        newMenuPanel.add(typeLabel, c);

        String[] types = {"Veg", "Non Veg"};
        itemTypeCombo = new JComboBox<>(types);
        c.gridx = 1;
        newMenuPanel.add(itemTypeCombo, c);

        JLabel priceLabel = new JLabel("Price:");
        c.gridx = 0;
        c.gridy = 4;
        newMenuPanel.add(priceLabel, c);

        priceField = new JTextField(10);
        c.gridx = 1;
        newMenuPanel.add(priceField, c);

        JButton addButton = new JButton("Add");
        c.gridx = 0;
        c.gridy = 5;
        newMenuPanel.add(addButton, c);
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                add();
            }
        });

        JButton deleteButton = new JButton("Delete");
        c.gridx = 1;
        newMenuPanel.add(deleteButton, c);
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                delete();
            }
        });

        JButton clearButton = new JButton("Clear");
        c.gridx = 2;
        newMenuPanel.add(clearButton, c);
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clear();
            }
        });

        menuFrame.add(newMenuPanel);
        menuFrame.setVisible(true);
    }

    private void add() {
        String itemID = itemIDField.getText();
        String itemName = itemNameField.getText();
        String category = categoryCombo.getSelectedItem().toString();
        String itemType = itemTypeCombo.getSelectedItem().toString();
        String price = priceField.getText();

        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/rms", "root", "#Lakshanika2004");
            String sql = "INSERT INTO menu (item_id, item_name, category, item_type, price) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, itemID);
            statement.setString(2, itemName);
            statement.setString(3, category);
            statement.setString(4, itemType);
            statement.setString(5, price);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void delete() {
        String itemID = itemIDField.getText();
        String itemName = itemNameField.getText();

        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/javamini", "root", "Shree@1109");
            String sql = "DELETE FROM menu WHERE item_id = ? OR item_name = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, itemID);
            statement.setString(2, itemName);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    private void clear() {
        itemIDField.setText("");
        itemNameField.setText("");
        priceField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new AddMenuWindow();
            }
        });
    }
}
