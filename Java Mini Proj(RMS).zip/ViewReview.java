import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ViewReview {

    public void openReview() {
        JFrame frame = new JFrame("Past Review");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        // Create a panel for the title
        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel("Past Review");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titlePanel.setBackground(new Color(14, 236, 228)); // Set your desired background color
        titlePanel.setForeground(Color.WHITE); // Set text color
        titlePanel.add(titleLabel);

        // Create a table model to hold the data
        DefaultTableModel model = new DefaultTableModel();
        JTable reviewTable = new JTable(model);
        reviewTable.setGridColor(Color.BLACK); // Set grid color
        reviewTable.setBackground(new Color(240, 240, 240)); // Set table background color

        // Add columns to the table model
        model.addColumn("Customer Name");
        model.addColumn("Phone no.");
        model.addColumn("Date");
        model.addColumn("Rating");
        model.addColumn("Review");

        try {
            // Connect to the database
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/rms", "root", "#Lakshanika2004");

            // Execute a SQL query to retrieve data from the menu table
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM reviews";
            ResultSet resultSet = statement.executeQuery(query);

            // Populate the table model with data from the query result
            while (resultSet.next()) {
                model.addRow(new Object[]{
                    resultSet.getString("customer_name"),
                    resultSet.getString("phone_number"),
                    resultSet.getString("date"),
                    resultSet.getString("rating"),
                    resultSet.getString("review")
                });
            }

            // Close the database connection
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(reviewTable);

        // Set the appearance of the frame
        frame.getContentPane().setBackground(new Color(255, 255, 255)); // Set the background color of the frame

        // Add the title panel to the frame at the top
        frame.add(titlePanel, BorderLayout.NORTH);

        // Add the table to the frame
        frame.add(scrollPane);

        frame.setVisible(true);
    }
}
