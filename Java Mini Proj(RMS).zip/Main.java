import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame root = new JFrame("Restaurant Management System");
        root.setSize(1550, 850);
        root.setLayout(null);
        root.setVisible(true);
        root.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        ImageIcon bgImage = new ImageIcon("C:\\Users\\laksh\\HTML website creation\\bg3.jpg");
        Image img = bgImage.getImage();
        Image temp = img.getScaledInstance(1550, 800, Image.SCALE_SMOOTH);
        bgImage = new ImageIcon(temp);
        JLabel bg = new JLabel("", bgImage, JLabel.CENTER);
        bg.setBounds(0, 0, 1550, 800);
        root.add(bg);

        JLabel title = new JLabel("Restaurant Management System");
        title.setForeground(Color.BLACK);
        title.setBackground(new Color(96, 244, 238));
        title.setFont(new Font("Courier New", Font.BOLD, 50));
        title.setBounds(300, 0, 900, 60);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        title.setOpaque(true);
        bg.add(title);

        JPanel black = new JPanel(null);
        black.setBackground(Color.BLACK);
        black.setBounds(0, 100, 1535, 90);
        bg.add(black);

        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem viewMenuItem = new JMenuItem("View Menu");
        viewMenuItem.setFont(new Font("Courier New", Font.BOLD, 20));
        viewMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        new Menutable();
                    }
                });
            }
        });
        popupMenu.add(viewMenuItem);

        JMenuItem addItemMenuItem = new JMenuItem("Add Menu Item");
        addItemMenuItem.setFont(new Font("Courier New", Font.BOLD, 20));
        addItemMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        new AddMenuWindow();
                    }
                });
            }
        });
        popupMenu.add(addItemMenuItem);

        JButton menuBtn = new JButton("Menu");
        menuBtn.setFont(new Font("Courier New", Font.BOLD, 35));
        menuBtn.setForeground(Color.BLACK);
        menuBtn.setBackground(new Color(13, 236, 228));
        menuBtn.setBounds(250, 25, 180, 40);
        menuBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                popupMenu.setPopupSize(200, 100);
                popupMenu.show(menuBtn, 0, menuBtn.getHeight());
            }
        });
        black.add(menuBtn);

        JButton orderBtn = new JButton("Order");
        orderBtn.setFont(new Font("Courier New", Font.BOLD, 35));
        orderBtn.setForeground(Color.BLACK);
        orderBtn.setBackground(new Color(13, 236, 228));
        orderBtn.setBounds(455, 25, 180, 40);
        orderBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Billing b = new Billing();
                b.openBilling();
            }
        });
        black.add(orderBtn);

        JButton custBtn = new JButton("Customer");
        custBtn.setFont(new Font("Courier New", Font.BOLD, 35));
        custBtn.setForeground(Color.BLACK);
        custBtn.setBackground(new Color(13, 236, 228));
        custBtn.setBounds(660, 25, 210, 40);
        custBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                CustomerList cl = new CustomerList();
                cl.openCustomer();
            }
        });
        black.add(custBtn);

        JPopupMenu popupReview = new JPopupMenu();
        JMenuItem RateReview = new JMenuItem("Rate and Review");
        RateReview.setFont(new Font("Courier New", Font.BOLD, 20));
        RateReview.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        new Restaurant_Review();
                    }
                });
            }
        });
        popupReview.add(RateReview);

        JMenuItem viewReview = new JMenuItem("View Past Reviews");
        viewReview.setFont(new Font("Courier New", Font.BOLD, 20));
        viewReview.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        ViewReview vr=new ViewReview();
                        vr.openReview();
                    }
                });
            }
        });
        popupReview.add(viewReview);

        JButton reviewBtn = new JButton("Review");
        reviewBtn.setFont(new Font("Courier New", Font.BOLD, 35));
        reviewBtn.setForeground(Color.BLACK);
        reviewBtn.setBackground(new Color(13, 236, 228));
        reviewBtn.setBounds(895, 25, 180, 40);
        reviewBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                popupReview.setPopupSize(220, 100);
                popupReview.show(reviewBtn, 0, reviewBtn.getHeight());
            }
        });
        black.add(reviewBtn);

        JButton exitBtn = new JButton("Exit");
        exitBtn.setFont(new Font("Courier New", Font.BOLD, 35));
        exitBtn.setForeground(Color.BLACK);
        exitBtn.setBackground(new Color(13, 236, 228));
        exitBtn.setBounds(1100, 25, 180, 40);
        exitBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        black.add(exitBtn);

        JPanel black2 = new JPanel(null);
        black2.setBackground(Color.BLACK);
        black2.setBounds(450, 300, 600, 400);
        bg.add(black2);


        ImageIcon bgImage1 = new ImageIcon("C:\\Users\\laksh\\Downloads\\menu_book_food_drink_icon_146855.png");
        Image img1 = bgImage1.getImage();
        Image temp1 = img1.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        bgImage1 = new ImageIcon(temp1);
        JLabel bg1 = new JLabel("", bgImage1, JLabel.CENTER);
        bg1.setBounds(10, 30, 150, 150);
        black2.add(bg1);

        ImageIcon bgImage2 = new ImageIcon("C:\\Users\\laksh\\Downloads\\invoice_document_bill_delivery_note_icon_225179.png");
        Image img2 = bgImage2.getImage();
        Image temp2 = img2.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        bgImage2 = new ImageIcon(temp2);
        JLabel bg2 = new JLabel("", bgImage2, JLabel.CENTER);
        bg2.setBounds(200, 30, 150, 150);
        black2.add(bg2);

        ImageIcon bgImage3 = new ImageIcon("C:\\Users\\laksh\\Downloads\\cashier_machine_cash_register_pos_icon_225201.png");
        Image img3 = bgImage3.getImage();
        Image temp3 = img3.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        bgImage3 = new ImageIcon(temp3);
        JLabel bg3 = new JLabel("", bgImage3, JLabel.CENTER);
        bg3.setBounds(400, 30, 150, 150);
        black2.add(bg3);

        ImageIcon bgImage4 = new ImageIcon("C:\\Users\\laksh\\Downloads\\frappe_cup_glass_coffee_take_away_drink_icon_210219.png");
        Image img4 = bgImage4.getImage();
        Image temp4 = img4.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        bgImage4 = new ImageIcon(temp4);
        JLabel bg4 = new JLabel("", bgImage4, JLabel.CENTER);
        bg4.setBounds(10, 210, 150, 150);
        black2.add(bg4);

        ImageIcon bgImage5 = new ImageIcon("C:\\Users\\laksh\\Downloads\\pizza_food_fast_food_italian_food_icon_207990.png");
        Image img5 = bgImage5.getImage();
        Image temp5 = img5.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        bgImage5 = new ImageIcon(temp5);
        JLabel bg5 = new JLabel("", bgImage5, JLabel.CENTER);
        bg5.setBounds(200, 210, 150, 150);
        black2.add(bg5);

        ImageIcon bgImage6 = new ImageIcon("C:\\Users\\laksh\\Downloads\\noodles_asian_food_food_bowl_spaghetti_pasta_icon_207994.png");
        Image img6 = bgImage6.getImage();
        Image temp6 = img6.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        bgImage6 = new ImageIcon(temp6);
        JLabel bg6 = new JLabel("", bgImage6, JLabel.CENTER);
        bg6.setBounds(400, 210, 150, 150);
        black2.add(bg6);


    }
}
