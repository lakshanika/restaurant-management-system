import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import java.sql.*;
import java.util.ArrayList;


public class Billing {
    private static JTextArea textArea;
    private static JTextField cphoneEntry,cnameEntry,prateEntry,pqtyEntry;
    private static JComboBox pName;
    private static JTable priceList;
    private static String bill_no=generateRandomBillNo();
    private static ArrayList<Integer> prices = new ArrayList<>();

    private static String generateRandomBillNo() {
        int n = (int) (Math.random() * 9000) + 1000;
        return String.valueOf(n);
    }

    
    public void openBilling() {
        JFrame root = new JFrame("Place Order");
        root.setSize(1550, 850);
        root.setLayout(null);
        root.setVisible(true);
        root.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        ImageIcon bgImage = new ImageIcon("C:\\Users\\laksh\\HTML website creation\\bg3.jpg");
        Image img = bgImage.getImage();
        Image temp = img.getScaledInstance(1550, 800, Image.SCALE_SMOOTH);
        bgImage = new ImageIcon(temp);
        JLabel bg = new JLabel("", bgImage, JLabel.CENTER);
        bg.setBounds(0, 0, 1550, 800);
        root.add(bg);

        JLabel title = new JLabel("Billing Area");
        title.setForeground(Color.BLACK);
        title.setBackground(new Color(96, 244, 238));
        title.setFont(new Font("Courier New", Font.BOLD, 45));
        title.setBounds(600, 0, 350, 50);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        title.setOpaque(true);
        bg.add(title);

        JPanel black = new JPanel(null);
        black.setBackground(Color.BLACK);
        black.setBounds(90, 70, 1350, 670);
        bg.add(black);

        JPanel orderPanel = new JPanel();
        orderPanel.setBackground(new Color(14, 236, 228));
        orderPanel.setBorder(BorderFactory.createEmptyBorder());
        orderPanel.setFont(new Font("Courier New", Font.BOLD, 15));
        orderPanel.setLayout(null);
        orderPanel.setBounds(20, 20, 1307, 630);
        black.add(orderPanel);

        JPanel customerPanel = new JPanel();
        customerPanel.setBackground(Color.BLACK);
        customerPanel.setLayout(null);
        customerPanel.setBounds(5, 5, (int) (1307 * 0.993), 80);

        TitledBorder customerBorder = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY, 3), "Customer Detail");
        customerBorder.setTitleColor(Color.WHITE);
        customerBorder.setTitleFont(new Font("Courier New", Font.BOLD, 20));
        customerPanel.setBorder(customerBorder);
        orderPanel.add(customerPanel);

        JLabel cnameLbl = new JLabel("Customer Name:");
        cnameLbl.setForeground(Color.WHITE);
        cnameLbl.setFont(new Font("Courier New", Font.BOLD, 20));
        cnameLbl.setBounds(20, 30, 200, 30);
        customerPanel.add(cnameLbl);

        cnameEntry = new JTextField();
        cnameEntry.setFont(new Font("Courier New", Font.BOLD, 20));
        cnameEntry.setBounds(220, 30, 200, 30);
        customerPanel.add(cnameEntry);

        JLabel cphoneLbl = new JLabel("Customer Phone:");
        cphoneLbl.setForeground(Color.WHITE);
        cphoneLbl.setFont(new Font("Courier New", Font.BOLD, 20));
        cphoneLbl.setBounds(440, 30, 200, 30);
        customerPanel.add(cphoneLbl);

        cphoneEntry = new JTextField();
        cphoneEntry.setFont(new Font("Courier New", Font.BOLD, 20));
        cphoneEntry.setBounds(640, 30, 200, 30);
        customerPanel.add(cphoneEntry);

        JButton okBtn = new JButton("OK");
        okBtn.setFont(new Font("Courier New", Font.BOLD, 15));
        okBtn.setBackground(Color.WHITE);
        okBtn.setBounds(880, 30, 100, 30);
        okBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                welcome();
            }
        });
        customerPanel.add(okBtn);

         // Create a product panel with a titled border
        JPanel productPanel = new JPanel();
        productPanel.setBackground(Color.BLACK);
        productPanel.setLayout(null);
        productPanel.setBounds(5, 120, 480, 480);

        // Add a titled border to the product panel
        //TitledBorder productBorder = BorderFactory.createTitledBorder("Product Detail");
        //productBorder.setTitleColor(Color.WHITE);
        TitledBorder productBorder = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY, 3), "Product Detail");
        productBorder.setTitleColor(Color.WHITE);
        productBorder.setTitleFont(new Font("Courier New", Font.BOLD, 20));
        productPanel.setBorder(productBorder);
        orderPanel.add(productPanel);

        JLabel pnameLbl = new JLabel("Product:");
        pnameLbl.setForeground(Color.WHITE);
        pnameLbl.setFont(new Font("Courier New", Font.BOLD, 20));
        pnameLbl.setBounds(20, 35, 150, 30);
        productPanel.add(pnameLbl);

        
        pName=new JComboBox();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rms", "root", "#Lakshanika2004");
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery("SELECT item_name from menu");

            while (rs.next()) {
                pName.addItem(rs.getString(1));
            }
            con.close();
            pName.setFont(new Font("Courier New", Font.BOLD, 15));
            pName.setBounds(170,35,250,30);
            productPanel.add(pName);
            pName.setSelectedItem(null);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        JLabel prateLbl = new JLabel("Rate:");
        prateLbl.setForeground(Color.WHITE);
        prateLbl.setFont(new Font("Courier New", Font.BOLD, 20));
        prateLbl.setBounds(35, 100, 150, 30);
        productPanel.add(prateLbl);

        prateEntry = new JTextField();
        prateEntry.setFont(new Font("Courier New", Font.BOLD, 20));
        prateEntry.setBounds(185, 100, 200, 30);
        productPanel.add(prateEntry);

        JLabel pqtyLbl = new JLabel("Quantity:");
        pqtyLbl.setForeground(Color.WHITE);
        pqtyLbl.setFont(new Font("Courier New", Font.BOLD, 20));
        pqtyLbl.setBounds(20, 165, 150, 30);
        productPanel.add(pqtyLbl);

        pqtyEntry = new JTextField();
        pqtyEntry.setFont(new Font("Courier New", Font.BOLD, 20));
        pqtyEntry.setBounds(185, 165, 200, 30);
        productPanel.add(pqtyEntry);         
        
        JButton addBtn = new JButton("Add Item");
        addBtn.setFont(new Font("Courier New", Font.BOLD, 15));
        addBtn.setBackground(Color.WHITE);
        addBtn.setBounds(60, 270, 150, 40);
        addBtn.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
                add();
            }
        });
        productPanel.add(addBtn);
        
        JButton billBtn = new JButton("Generate Bill");
        billBtn.setFont(new Font("Courier New", Font.BOLD, 15));
        billBtn.setBackground(Color.WHITE);
        billBtn.setBounds(250, 270, 150, 40);
        billBtn.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
                bill();
            }
        });
        productPanel.add(billBtn);
        
        JButton removeBtn = new JButton("Clear");
        removeBtn.setFont(new Font("Courier New", Font.BOLD, 15));
        removeBtn.setBackground(Color.WHITE);
        removeBtn.setBounds(60, 350, 150, 40);
        removeBtn.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
                clear();
            }
        });
        productPanel.add(removeBtn);
        
        JButton priceListBtn = new JButton("Price List");
        priceListBtn.setFont(new Font("Courier New", Font.BOLD, 15));
        priceListBtn.setBackground(Color.WHITE);
        priceListBtn.setBounds(250, 350, 150, 40);
        priceListBtn.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
                pricelist();
            }
        });
        productPanel.add(priceListBtn);
        

        JPanel billAreaFrame = new JPanel(null);
        billAreaFrame.setBackground(Color.WHITE);
        //billAreaFrame.setBorder(BorderFactory.createLineBorder(Color.lightGray, 5));
        billAreaFrame.setBounds(520, 120, 750, 480);
        orderPanel.add(billAreaFrame);

        JLabel billTitle = new JLabel("Bill Area");
        billTitle.setFont(new Font("Courier New", Font.BOLD, 30));
        billTitle.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 7));
        billTitle.setHorizontalAlignment(SwingConstants.CENTER);
        billTitle.setBounds(0, 0, 750, 50);
        billAreaFrame.add(billTitle);

        textArea = new JTextArea();
        textArea.setFont(new Font("Courier New", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(0, 45, 750, 430);
       
        billAreaFrame.add(scrollPane);

        cnameEntry.requestFocus();

        root.repaint();
        root.revalidate();
    }

    public static void welcome() {
        textArea.setText("");
        textArea.append("\t\tWelcome To The Restaurant\n");
        textArea.append("Bill No: " + bill_no + "\n");
        textArea.append("\t\t\t\tCustomer Name: " + cnameEntry.getText() + "\n");
        textArea.append("Phone: " + cphoneEntry.getText() + "\n");
        textArea.append("=========================================================\n");
        textArea.append("\tProduct\t\tQuantity\t\tPrice\n");
        textArea.append("=========================================================\n");
    
        Font font = new Font("Courier New", Font.BOLD, 20);
        textArea.setFont(font);
    }

    public static void add() {
        if (pName.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Item cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            String selectedProduct = pName.getSelectedItem().toString();
            int selectedRate = Integer.parseInt(prateEntry.getText());
            int selectedQty = Integer.parseInt(pqtyEntry.getText());
            int amt = selectedRate * selectedQty;
            prices.add(amt);
            textArea.append(String.format("\n\t%s\t\t%d\t\t%d", selectedProduct, selectedQty, amt));
    
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rms", "root", "#Lakshanika2004");
                Statement stm = con.createStatement();
                String query = String.format("INSERT INTO bill(item_name, quantity, price, bill_no) values('%s', %d, %d, %s)", selectedProduct, selectedQty, selectedRate, bill_no);
                stm.executeUpdate(query);
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
    
            // Reset the entry fields
            pName.setSelectedItem(null);
            prateEntry.setText("");
            pqtyEntry.setText("");
            pName.requestFocus();
        }
    }
    

    public static void clear() {
        cnameEntry.setText("");
        cphoneEntry.setText("");
        pqtyEntry.setText("");
        prateEntry.setText("");
        pName.setSelectedItem(null);
        textArea.setText("");
    }

    public static void bill() {
        textArea.append("\n=========================================================\n");
        int totalBill = calculateTotalBill();
        textArea.append(String.format("\t\tTotal Bill Amount:\t\t%d", totalBill));
        textArea.append("\n=========================================================\n");

        // Storing in Database
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rms", "root", "#Lakshanika2004");
            Statement stm = con.createStatement();
            String query = String.format("INSERT INTO customer(cust_name, cust_phone, bill_no, tot_bill) values('%s', '%s', %s, %d)",
                                        cnameEntry.getText(), cphoneEntry.getText(), bill_no, totalBill);
            stm.executeUpdate(query);
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static int calculateTotalBill() {
        int total = 0;
        for (int price : prices) {
            total += price;
        }
        return total;
    }

    public static void pricelist() {
        JFrame window = new JFrame("Price List");
        window.setSize(1200, 800);
        window.setLayout(new BorderLayout());
        window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel dataFrame = new JPanel();
        dataFrame.setBorder(BorderFactory.createTitledBorder("Price List"));
        dataFrame.setBackground(Color.black);
        dataFrame.setLayout(new BorderLayout());
        window.add(dataFrame, BorderLayout.CENTER);

        JPanel searchFrame = new JPanel();
        searchFrame.setBackground(new Color(96, 244, 238));
        dataFrame.add(searchFrame, BorderLayout.NORTH);

        JButton viewBtn = new JButton("View Price");
        viewBtn.setFont(new Font("Courier New", Font.BOLD, 15));
        viewBtn.setForeground(Color.white);
        viewBtn.setBackground(Color.black);
        viewBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                view();
            }
        });
        searchFrame.add(viewBtn);

        String[] columns = {"Item Name", "Price"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        priceList = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(priceList);
        dataFrame.add(scrollPane, BorderLayout.CENTER);

        window.setVisible(true);
    }

    public static void view() {
        DefaultTableModel model = (DefaultTableModel) priceList.getModel();
        model.setRowCount(0);

        // Incorporate your Python code here
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rms", "root", "#Lakshanika2004");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT item_name, price FROM menu");

            while (rs.next()) {
                String itemName = rs.getString("item_name");
                int price = rs.getInt("price");
                model.addRow(new Object[]{itemName, price});
            }

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }    
}