import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Menutable extends JFrame {
    public Menutable() {
        setTitle("Menu Table");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Create a panel for the title
        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel("Menu");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titlePanel.setBackground(new Color(14, 236, 228)); // Set your desired background color
        titlePanel.setForeground(Color.WHITE); // Set text color
        titlePanel.add(titleLabel);

        // Create a table model to hold the data
        DefaultTableModel model = new DefaultTableModel();
        JTable menuTable = new JTable(model);
        menuTable.setGridColor(Color.BLACK); // Set grid color
        menuTable.setBackground(new Color(240, 240, 240)); // Set table background color

        // Add columns to the table model
        model.addColumn("Item ID");
        model.addColumn("Item Name");
        model.addColumn("Category");
        model.addColumn("Item Type");
        model.addColumn("Price");

        try {
            // Connect to the database
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/rms", "root", "#Lakshanika2004");

            // Execute a SQL query to retrieve data from the menu table
            Statement statement = connection.createStatement();
            String query = "SELECT item_id, item_name, category, item_type, price FROM menu";
            ResultSet resultSet = statement.executeQuery(query);

            // Populate the table model with data from the query result
            while (resultSet.next()) {
                model.addRow(new Object[]{
                    resultSet.getString("item_id"),
                    resultSet.getString("item_name"),
                    resultSet.getString("category"),
                    resultSet.getString("item_type"),
                    resultSet.getString("price")
                });
            }

            // Close the database connection
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(menuTable);

        // Set the appearance of the frame
        getContentPane().setBackground(new Color(255, 255, 255)); // Set the background color of the frame

        // Add the title panel to the frame at the top
        add(titlePanel, BorderLayout.NORTH);

        // Add the table to the frame
        add(scrollPane);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Menutable();
            }
        });
    }
}
